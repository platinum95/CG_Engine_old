
#ifndef COMMON_H
#define COMMON_H

//#define GLFW_DLL

//#include <GL/glew.h>
#include <glad/glad.h>
#include <GLFW/glfw3.h>

#endif