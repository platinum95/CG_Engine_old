OpenGL core functionality, calls, etc handled by code in CG_Engine folder.

Code in this folder is "implementation" of the "Engine"